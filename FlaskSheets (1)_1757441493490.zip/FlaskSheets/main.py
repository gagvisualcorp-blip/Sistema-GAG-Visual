from app import app, db
import logging
from auto_data_collector import init_auto_collector

with app.app_context():
    # Import models to ensure tables are created
    import models  # noqa: F401
    db.create_all()
    logging.info("Database tables created successfully")
    
    # Inicializar coleta automática de dados
    init_auto_collector()

# Import routes
import routes  # noqa: F401
import api_routes  # noqa: F401
import portfolio_routes  # noqa: F401

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
