import os
import logging
import gspread
from google.auth import default
from google.auth.exceptions import DefaultCredentialsError
from datetime import datetime
from typing import List, Dict, Optional
from models import FlowData, SyncLog
from app import db

logger = logging.getLogger(__name__)

class GoogleSheetsService:
    """Service class for handling Google Sheets integration"""
    
    def __init__(self):
        self.client = None
        self.spreadsheet = None
        self.worksheet = None
        self.sheet_url = os.environ.get('GOOGLE_SHEET_URL', '')
        self.sheet_name = os.environ.get('GOOGLE_SHEET_NAME', 'GAG Flow Data')
        self._initialize_client()
    
    def _initialize_client(self):
        """Initialize Google Sheets client with proper authentication"""
        try:
            # Try to use default credentials (service account or user credentials)
            creds, _ = default(scopes=[
                'https://www.googleapis.com/auth/spreadsheets',
                'https://www.googleapis.com/auth/drive'
            ])
            self.client = gspread.authorize(creds)
            logger.info("Google Sheets client initialized successfully")
        except DefaultCredentialsError as e:
            logger.error(f"Failed to initialize Google Sheets client: {e}")
            self.client = None
        except Exception as e:
            logger.error(f"Unexpected error initializing Google Sheets client: {e}")
            self.client = None
    
    def connect_to_sheet(self) -> bool:
        """Connect to the specified Google Sheet"""
        if not self.client:
            logger.error("Google Sheets client not initialized")
            return False
        
        try:
            if self.sheet_url:
                self.spreadsheet = self.client.open_by_url(self.sheet_url)
            else:
                # Try to find or create sheet by name
                try:
                    self.spreadsheet = self.client.open(self.sheet_name)
                except gspread.SpreadsheetNotFound:
                    logger.info(f"Sheet '{self.sheet_name}' not found, creating new one")
                    self.spreadsheet = self.client.create(self.sheet_name)
            
            # Get or create the main worksheet
            try:
                self.worksheet = self.spreadsheet.worksheet("GAG Data")
            except gspread.WorksheetNotFound:
                self.worksheet = self.spreadsheet.add_worksheet("GAG Data", 1000, 10)
                self._setup_worksheet_headers()
            
            logger.info(f"Connected to Google Sheet: {self.spreadsheet.title}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to Google Sheet: {e}")
            return False
    
    def _setup_worksheet_headers(self):
        """Set up headers for the worksheet"""
        headers = [
            'Timestamp', 'Flow Rate', 'Pressure', 'Temperature',
            'Status', 'Location', 'Device ID', 'Notes'
        ]
        try:
            self.worksheet.update('A1:H1', [headers])
            logger.info("Worksheet headers set up successfully")
        except Exception as e:
            logger.error(f"Failed to set up worksheet headers: {e}")
    
    def sync_to_sheets(self, flow_data_records: List[FlowData]) -> Dict[str, any]:
        """Sync flow data records to Google Sheets"""
        if not self.worksheet:
            if not self.connect_to_sheet():
                return {'success': False, 'error': 'Failed to connect to Google Sheets'}
        
        try:
            # Prepare data for batch update
            rows_to_add = []
            for record in flow_data_records:
                row = [
                    record.timestamp.strftime('%Y-%m-%d %H:%M:%S') if record.timestamp else '',
                    record.flow_rate or '',
                    record.pressure or '',
                    record.temperature or '',
                    record.status or '',
                    record.location or '',
                    record.device_id or '',
                    record.notes or ''
                ]
                rows_to_add.append(row)
            
            if rows_to_add:
                # Find the next empty row
                all_values = self.worksheet.get_all_values()
                next_row = len(all_values) + 1
                
                # Append the data
                range_name = f'A{next_row}:H{next_row + len(rows_to_add) - 1}'
                self.worksheet.update(range_name, rows_to_add)
                
                # Mark records as synced
                for record in flow_data_records:
                    record.synced_to_sheets = True
                db.session.commit()
                
                # Log the sync
                sync_log = SyncLog(
                    records_synced=len(flow_data_records),
                    sync_status='success',
                    sync_direction='to_sheets'
                )
                db.session.add(sync_log)
                db.session.commit()
                
                logger.info(f"Successfully synced {len(flow_data_records)} records to Google Sheets")
                return {'success': True, 'records_synced': len(flow_data_records)}
            else:
                return {'success': True, 'records_synced': 0, 'message': 'No records to sync'}
        
        except Exception as e:
            error_msg = f"Failed to sync data to Google Sheets: {e}"
            logger.error(error_msg)
            
            # Log the error
            sync_log = SyncLog(
                records_synced=0,
                sync_status='error',
                error_message=str(e),
                sync_direction='to_sheets'
            )
            db.session.add(sync_log)
            db.session.commit()
            
            return {'success': False, 'error': error_msg}
    
    def sync_from_sheets(self) -> Dict[str, any]:
        """Sync data from Google Sheets to local database"""
        if not self.worksheet:
            if not self.connect_to_sheet():
                return {'success': False, 'error': 'Failed to connect to Google Sheets'}
        
        try:
            # Get all data from the sheet
            all_records = self.worksheet.get_all_records()
            new_records_count = 0
            
            for row in all_records:
                # Check if record already exists (based on timestamp and flow_rate)
                timestamp_str = row.get('Timestamp', '')
                if timestamp_str:
                    try:
                        timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
                        flow_rate = float(row.get('Flow Rate', 0)) if row.get('Flow Rate') else None
                        
                        if flow_rate is not None:
                            # Check if record exists
                            existing = FlowData.query.filter_by(
                                timestamp=timestamp,
                                flow_rate=flow_rate
                            ).first()
                            
                            if not existing:
                                # Create new record
                                new_record = FlowData(
                                    timestamp=timestamp,
                                    flow_rate=flow_rate,
                                    pressure=float(row.get('Pressure')) if row.get('Pressure') else None,
                                    temperature=float(row.get('Temperature')) if row.get('Temperature') else None,
                                    status=row.get('Status', 'active'),
                                    location=row.get('Location'),
                                    device_id=row.get('Device ID'),
                                    notes=row.get('Notes'),
                                    synced_to_sheets=True
                                )
                                db.session.add(new_record)
                                new_records_count += 1
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Skipping invalid row: {row}, error: {e}")
                        continue
            
            db.session.commit()
            
            # Log the sync
            sync_log = SyncLog(
                records_synced=new_records_count,
                sync_status='success',
                sync_direction='from_sheets'
            )
            db.session.add(sync_log)
            db.session.commit()
            
            logger.info(f"Successfully synced {new_records_count} new records from Google Sheets")
            return {'success': True, 'records_synced': new_records_count}
        
        except Exception as e:
            error_msg = f"Failed to sync data from Google Sheets: {e}"
            logger.error(error_msg)
            
            # Log the error
            sync_log = SyncLog(
                records_synced=0,
                sync_status='error',
                error_message=str(e),
                sync_direction='from_sheets'
            )
            db.session.add(sync_log)
            db.session.commit()
            
            return {'success': False, 'error': error_msg}
    
    def test_connection(self) -> Dict[str, any]:
        """Test the connection to Google Sheets"""
        if not self.client:
            return {'success': False, 'error': 'Google Sheets client not initialized'}
        
        try:
            if self.connect_to_sheet():
                return {
                    'success': True,
                    'sheet_title': self.spreadsheet.title if self.spreadsheet else 'Unknown',
                    'worksheet_title': self.worksheet.title if self.worksheet else 'Unknown'
                }
            else:
                return {'success': False, 'error': 'Failed to connect to sheet'}
        except Exception as e:
            return {'success': False, 'error': str(e)}

# Create a global instance
sheets_service = GoogleSheetsService()
