import os
import logging
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "gag-dashboard-secret-key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///gag_visual.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Configurações Google Sheets
app.config['GOOGLE_SHEETS_ID'] = os.environ.get('GOOGLE_SHEETS_ID', '')
app.config['GOOGLE_CREDENTIALS_PATH'] = os.path.join(os.path.dirname(__file__), 'attached_assets/credenciais_1_1757430536161.json')

# Initialize the app with the extension
db.init_app(app)

@app.route('/')
def home():
    return render_template('dashboard.html')
