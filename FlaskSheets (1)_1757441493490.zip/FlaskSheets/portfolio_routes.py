import os
from flask import request, jsonify, redirect, url_for, flash
from werkzeug.utils import secure_filename
from app import app

# Configurações de upload
UPLOAD_FOLDER = 'static/portfolio'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'mp4', 'webm', 'ogg'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/upload_portfolio', methods=['POST'])
def upload_portfolio():
    try:
        if 'arquivo' not in request.files:
            flash('Nenhum arquivo selecionado', 'error')
            return redirect(url_for('home'))
        
        file = request.files['arquivo']
        titulo = request.form.get('titulo', '')
        descricao = request.form.get('descricao', '')
        
        if file.filename == '':
            flash('Nenhum arquivo selecionado', 'error')
            return redirect(url_for('home'))
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            
            # Criar diretório se não existir
            os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
            
            # Salvar arquivo
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            # Aqui você pode salvar os metadados no banco de dados se desejar
            # Por exemplo: título, descrição, caminho do arquivo, data de upload
            
            flash('Arquivo adicionado ao portfólio com sucesso!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Tipo de arquivo não permitido', 'error')
            return redirect(url_for('home'))
            
    except Exception as e:
        flash(f'Erro ao fazer upload: {str(e)}', 'error')
        return redirect(url_for('home'))

@app.route('/api/portfolio')
def api_portfolio():
    """API para listar arquivos do portfólio"""
    try:
        portfolio_dir = app.config['UPLOAD_FOLDER']
        if not os.path.exists(portfolio_dir):
            return jsonify([])
        
        files = []
        for filename in os.listdir(portfolio_dir):
            if allowed_file(filename):
                file_path = os.path.join(portfolio_dir, filename)
                file_info = {
                    'filename': filename,
                    'url': url_for('static', filename=f'portfolio/{filename}'),
                    'type': 'video' if filename.lower().endswith(('.mp4', '.webm', '.ogg')) else 'image',
                    'size': os.path.getsize(file_path),
                    'modified': os.path.getmtime(file_path)
                }
                files.append(file_info)
        
        # Ordenar por data de modificação (mais recente primeiro)
        files.sort(key=lambda x: x['modified'], reverse=True)
        
        return jsonify(files)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500