from app import app, db
from flask import jsonify
from models import FlowData, SyncLog
from datetime import datetime, timedelta
from auto_data_collector import get_collector_status

def _agora():
    return datetime.utcnow()

@app.route('/api/kpis')
def api_kpis():
    agora = _agora()
    ha_24h = agora - timedelta(hours=24)

    # Registros de fluxo nas últimas 24h
    registros_24h = FlowData.query.filter(FlowData.timestamp >= ha_24h).count()

    # Dispositivos únicos nas últimas 24h
    dispositivos_24h = db.session.query(FlowData.device_id)\
        .filter(FlowData.timestamp >= ha_24h)\
        .distinct()\
        .count()

    # Projetos ativos (dispositivos com status ativo)
    dispositivos_ativos = FlowData.query.filter(FlowData.status == "active").count()

    # Taxa média de fluxo nas últimas 24h
    avg_flow = db.session.query(db.func.avg(FlowData.flow_rate))\
        .filter(FlowData.timestamp >= ha_24h)\
        .scalar() or 0

    return jsonify({
        "registros_hoje": registros_24h,
        "dispositivos_ativos": dispositivos_ativos,
        "dispositivos_24h": dispositivos_24h,
        "flow_medio_24h": round(avg_flow, 2)
    })

@app.route('/api/chart/fluxo_14d')
def api_chart_fluxo():
    hoje = _agora().date()
    labels = []
    valores = []

    for i in range(13, -1, -1):
        dia = hoje - timedelta(days=i)
        prox_dia = dia + timedelta(days=1)
        
        # Média de fluxo do dia
        avg_flow = db.session.query(db.func.avg(FlowData.flow_rate))\
            .filter(FlowData.timestamp >= datetime(dia.year, dia.month, dia.day),
                   FlowData.timestamp < datetime(prox_dia.year, prox_dia.month, prox_dia.day))\
            .scalar() or 0
            
        labels.append(dia.strftime('%d/%m'))
        valores.append(round(avg_flow, 2))

    return jsonify({"labels": labels, "valores": valores})

@app.route('/api/registros_recentes')
def api_registros_recentes():
    itens = FlowData.query.order_by(FlowData.timestamp.desc()).limit(10).all()
    data = [{
        "device_id": i.device_id or "-",
        "flow_rate": i.flow_rate,
        "status": i.status,
        "location": i.location or "-",
        "timestamp": i.timestamp.strftime('%d/%m %H:%M') if i.timestamp else "-"
    } for i in itens]
    return jsonify(data)

@app.route('/api/sync_status')
def api_sync_status():
    """Status da última sincronização"""
    ultimo_sync = SyncLog.query.order_by(SyncLog.sync_timestamp.desc()).first()
    if ultimo_sync:
        return jsonify({
            "ultimo_sync": ultimo_sync.sync_timestamp.strftime('%d/%m %H:%M'),
            "status": ultimo_sync.sync_status,
            "registros": ultimo_sync.records_synced,
            "direcao": ultimo_sync.sync_direction
        })
    else:
        return jsonify({
            "ultimo_sync": "Nunca",
            "status": "none",
            "registros": 0,
            "direcao": ""
        })

@app.route('/api/gestao_dados')
def api_gestao_dados():
    """API para dados de gestão"""
    try:
        # Stats gerais
        total_registros = FlowData.query.count()
        ultimo_registro_obj = FlowData.query.order_by(FlowData.timestamp.desc()).first()
        ultimo_registro = ultimo_registro_obj.timestamp.strftime('%d/%m %H:%M') if ultimo_registro_obj else 'Nenhum'
        
        # Média geral de fluxo
        media_geral = db.session.query(db.func.avg(FlowData.flow_rate)).scalar() or 0
        
        # Dispositivos únicos
        total_dispositivos = db.session.query(FlowData.device_id).distinct().count()
        dispositivos_ativos = FlowData.query.filter(FlowData.status == 'active').count()
        
        # Localizações únicas
        total_localizacoes = db.session.query(FlowData.location).distinct().count()
        
        # Lista de dispositivos com último status
        dispositivos_query = db.session.query(
            FlowData.device_id,
            FlowData.location,
            FlowData.flow_rate,
            FlowData.status,
            FlowData.timestamp
        ).distinct(FlowData.device_id).order_by(FlowData.device_id, FlowData.timestamp.desc()).all()
        
        dispositivos = []
        for d in dispositivos_query:
            dispositivos.append({
                'device_id': d.device_id,
                'location': d.location,
                'ultimo_flow': d.flow_rate,
                'status': d.status
            })
        
        # Status do sistema
        collector_status = get_collector_status()
        sistema_status = "Coleta Automática Ativa" if collector_status['active'] else "Manual"
        
        return jsonify({
            'total_registros': total_registros,
            'ultimo_registro': ultimo_registro,
            'media_geral': round(media_geral, 2),
            'status_sistema': sistema_status,
            'total_dispositivos': total_dispositivos,
            'dispositivos_ativos': dispositivos_ativos,
            'total_localizacoes': total_localizacoes,
            'dispositivos': dispositivos,
            'collector_info': collector_status
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/limpar_dados', methods=['POST'])
def api_limpar_dados():
    """Limpa todos os dados do sistema"""
    try:
        FlowData.query.delete()
        SyncLog.query.delete()
        db.session.commit()
        return jsonify({'success': True, 'message': 'Dados limpos com sucesso'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/collector_status')
def api_collector_status():
    """Status do sistema de coleta automática"""
    return jsonify(get_collector_status())