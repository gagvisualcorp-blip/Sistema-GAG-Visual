from app import app, db
from models import FlowData, SystemConfig, SyncLog
from datetime import datetime

with app.app_context():
    db.create_all()

    # Criar configurações iniciais do sistema
    configs = [
        {'key': 'google_sheet_url', 'value': '', 'description': 'URL da planilha Google Sheets'},
        {'key': 'google_sheet_name', 'value': 'GAG Flow Data', 'description': 'Nome da planilha'},
        {'key': 'auto_sync_interval', 'value': '30', 'description': 'Intervalo de sincronização automática (minutos)'},
        {'key': 'data_retention_days', 'value': '90', 'description': 'Dias de retenção de dados'},
        {'key': 'alert_flow_threshold', 'value': '0.5', 'description': 'Limite de alerta de fluxo (L/min)'},
        {'key': 'system_name', 'value': 'GAG Autonomous Flow Monitor', 'description': 'Nome do sistema'}
    ]
    
    for config_data in configs:
        existing = SystemConfig.query.filter_by(config_key=config_data['key']).first()
        if not existing:
            config = SystemConfig(
                config_key=config_data['key'],
                config_value=config_data['value'],
                description=config_data['description']
            )
            db.session.add(config)
    
    # Adicionar alguns dados de exemplo
    sample_data = [
        {'flow_rate': 1.2, 'pressure': 2.5, 'temperature': 22.5, 'status': 'active', 'location': 'Setor A', 'device_id': 'GAG-001'},
        {'flow_rate': 1.1, 'pressure': 2.3, 'temperature': 23.0, 'status': 'active', 'location': 'Setor B', 'device_id': 'GAG-002'},
        {'flow_rate': 0.9, 'pressure': 2.1, 'temperature': 22.8, 'status': 'warning', 'location': 'Setor C', 'device_id': 'GAG-003'}
    ]
    
    for data in sample_data:
        existing = FlowData.query.filter_by(device_id=data['device_id']).first()
        if not existing:
            flow_data = FlowData(**data)
            db.session.add(flow_data)
    
    db.session.commit()

print("✅ Sistema inicializado: GAG Flow Monitoring configurado com dados de exemplo.")