// Dashboard GAG Visual - JavaScript

let graficoFluxo = null;

// Atualizar relógio
function atualizarRelogio() {
    const agora = new Date();
    const horas = agora.getHours().toString().padStart(2, '0');
    const minutos = agora.getMinutes().toString().padStart(2, '0');
    const segundos = agora.getSeconds().toString().padStart(2, '0');
    document.getElementById('relogio').textContent = `Luanda: ${horas}:${minutos}:${segundos}`;
}

// Carregar KPIs
async function carregarKPIs() {
    try {
        const response = await fetch('/api/kpis');
        const data = await response.json();
        
        document.getElementById('registros_hoje').textContent = data.registros_hoje || 0;
        document.getElementById('dispositivos_ativos').textContent = data.dispositivos_ativos || 0;
        document.getElementById('flow_medio_24h').textContent = `${data.flow_medio_24h || 0} L/min`;
    } catch (error) {
        console.error('Erro ao carregar KPIs:', error);
    }
}

// Carregar gráfico
async function carregarGrafico() {
    try {
        const response = await fetch('/api/chart/fluxo_14d');
        const data = await response.json();
        
        const ctx = document.getElementById('graficoFluxo').getContext('2d');
        
        if (graficoFluxo) {
            graficoFluxo.destroy();
        }
        
        graficoFluxo = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels || [],
                datasets: [{
                    label: 'Fluxo Médio (L/min)',
                    data: data.valores || [],
                    borderColor: '#D4AF37',
                    backgroundColor: 'rgba(212, 175, 55, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Fluxo (L/min)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Últimos 14 dias'
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Erro ao carregar gráfico:', error);
    }
}

// Carregar tabela de registros recentes
async function carregarTabelaRegistros() {
    try {
        const response = await fetch('/api/registros_recentes');
        const data = await response.json();
        
        const tbody = document.getElementById('tabela_registros');
        tbody.innerHTML = '';
        
        data.forEach(registro => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${registro.device_id}</td>
                <td>${registro.flow_rate}</td>
                <td><span style="color: ${getStatusColor(registro.status)}">${registro.status}</span></td>
                <td>${registro.location}</td>
                <td>${registro.timestamp}</td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Erro ao carregar tabela:', error);
    }
}

function getStatusColor(status) {
    switch(status) {
        case 'active': return '#198754';
        case 'warning': return '#ffc107';
        case 'error': return '#dc3545';
        default: return '#6c757d';
    }
}

// Sincronizar com Google Sheets
async function syncSheets() {
    try {
        const response = await fetch('/sync_to_sheets');
        if (response.ok) {
            alert('Sincronização realizada com sucesso!');
            carregarDados(); // Recarregar dados
        } else {
            alert('Erro na sincronização');
        }
    } catch (error) {
        console.error('Erro na sincronização:', error);
        alert('Erro na sincronização');
    }
}

// Modal para adicionar dados
function adicionarDados() {
    document.getElementById('modalDados').style.display = 'block';
}

function fecharModal() {
    document.getElementById('modalDados').style.display = 'none';
}

// Submeter formulário
document.getElementById('formDados').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    try {
        const response = await fetch('/add_data', {
            method: 'POST',
            body: formData
        });
        
        if (response.ok) {
            alert('Dados adicionados com sucesso!');
            fecharModal();
            this.reset();
            carregarDados(); // Recarregar dados
        } else {
            alert('Erro ao adicionar dados');
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao adicionar dados');
    }
});

// Carregar todos os dados
function carregarDados() {
    carregarKPIs();
    carregarGrafico();
    carregarTabelaRegistros();
}

// Inicializar dashboard
document.addEventListener('DOMContentLoaded', function() {
    console.log('Inicializando GAG Visual Dashboard...');
    
    // Atualizar relógio
    atualizarRelogio();
    setInterval(atualizarRelogio, 1000);
    
    // Carregar dados iniciais
    carregarDados();
    
    // Auto-refresh a cada 30 segundos
    setInterval(carregarDados, 30000);
});

// Fechar modal ao clicar fora
document.getElementById('modalDados').addEventListener('click', function(e) {
    if (e.target === this) {
        fecharModal();
    }
});

// Funcionalidades do Portfólio
function togglePortfolio() {
    const portfolio = document.getElementById('portfolio');
    if (portfolio.style.display === 'none' || portfolio.style.display === '') {
        portfolio.style.display = 'block';
        portfolio.scrollIntoView({ behavior: 'smooth' });
    } else {
        portfolio.style.display = 'none';
    }
}

// Upload de arquivos do portfólio
document.getElementById('uploadForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const titulo = document.getElementById('titulo').value;
    const descricao = document.getElementById('descricao').value;
    const arquivo = document.getElementById('arquivo').files[0];
    
    if (!arquivo) {
        alert('Por favor, selecione um arquivo');
        return;
    }
    
    const formData = new FormData();
    formData.append('titulo', titulo);
    formData.append('descricao', descricao);
    formData.append('arquivo', arquivo);
    
    try {
        const response = await fetch('/upload_portfolio', {
            method: 'POST',
            body: formData
        });
        
        if (response.ok) {
            alert('Arquivo adicionado ao portfólio com sucesso!');
            this.reset();
            // Recarregar a página para mostrar o novo item
            location.reload();
        } else {
            alert('Erro ao fazer upload do arquivo');
        }
    } catch (error) {
        console.error('Erro no upload:', error);
        alert('Erro ao fazer upload do arquivo');
    }
});

// Funcionalidades de Gestão
function verGestaoClientes() {
    const gestao = document.getElementById('gestao');
    if (gestao.style.display === 'none' || gestao.style.display === '') {
        gestao.style.display = 'block';
        gestao.scrollIntoView({ behavior: 'smooth' });
        carregarDadosGestao();
    } else {
        gestao.style.display = 'none';
    }
}

function showTab(tabName) {
    // Esconder todos os tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Mostrar tab selecionado
    document.getElementById(`tab-${tabName}`).classList.add('active');
    event.target.classList.add('active');
    
    if (tabName === 'clientes' || tabName === 'dados') {
        carregarDadosGestao();
    }
}

async function carregarDadosGestao() {
    try {
        const response = await fetch('/api/gestao_dados');
        const data = await response.json();
        
        // Atualizar stats de dispositivos
        document.getElementById('total-dispositivos').textContent = data.total_dispositivos || 0;
        document.getElementById('dispositivos-ativos-count').textContent = data.dispositivos_ativos || 0;
        document.getElementById('localizacoes-count').textContent = data.total_localizacoes || 0;
        
        // Atualizar stats gerais
        document.getElementById('total-registros').textContent = data.total_registros || 0;
        document.getElementById('ultimo-registro').textContent = data.ultimo_registro || 'Nenhum';
        document.getElementById('media-geral').textContent = `${data.media_geral || 0} L/min`;
        document.getElementById('status-sistema').textContent = data.status_sistema || 'OK';
        
        // Lista de dispositivos
        const listaDispositivos = document.getElementById('lista-dispositivos');
        listaDispositivos.innerHTML = '';
        
        if (data.dispositivos && data.dispositivos.length > 0) {
            data.dispositivos.forEach(dispositivo => {
                const div = document.createElement('div');
                div.className = 'dispositivo-item';
                div.innerHTML = `
                    <strong>${dispositivo.device_id}</strong> - ${dispositivo.location}<br>
                    <small>Último fluxo: ${dispositivo.ultimo_flow} L/min | Status: ${dispositivo.status}</small>
                `;
                listaDispositivos.appendChild(div);
            });
        } else {
            listaDispositivos.innerHTML = '<p>Nenhum dispositivo encontrado</p>';
        }
        
    } catch (error) {
        console.error('Erro ao carregar dados de gestão:', error);
    }
}

async function limparDados() {
    if (confirm('⚠️ ATENÇÃO: Isso irá apagar TODOS os dados do sistema. Tem certeza?')) {
        try {
            const response = await fetch('/api/limpar_dados', { method: 'POST' });
            if (response.ok) {
                alert('Dados limpos com sucesso!');
                location.reload();
            } else {
                alert('Erro ao limpar dados');
            }
        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao limpar dados');
        }
    }
}

function gerarRelatorio() {
    window.open('/api/relatorio', '_blank');
}

function exportarDados() {
    window.open('/api/export_dados', '_blank');
}