// GAG Dashboard JavaScript functionality

// Global variables
let flowChart = null;
let refreshInterval = null;
let lastUpdateTime = null;

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    setupEventHandlers();
    startAutoRefresh();
});

/**
 * Initialize the dashboard
 */
function initializeDashboard() {
    console.log('Initializing GAG Dashboard...');
    
    // Load initial chart data
    loadChartData();
    
    // Update timestamps
    updateTimestamps();
    
    // Show welcome message if first time
    if (!localStorage.getItem('gag_dashboard_visited')) {
        showWelcomeMessage();
        localStorage.setItem('gag_dashboard_visited', 'true');
    }
}

/**
 * Setup event handlers
 */
function setupEventHandlers() {
    // Form validation for add data form
    const addDataForm = document.querySelector('form[action*="add_data"]');
    if (addDataForm) {
        addDataForm.addEventListener('submit', validateAddDataForm);
    }
    
    // Confirm delete actions
    document.querySelectorAll('a[onclick*="confirm"]').forEach(link => {
        link.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this record?')) {
                e.preventDefault();
                return false;
            }
        });
    });
    
    // Auto-save configuration
    const configForm = document.querySelector('form[action*="update_config"]');
    if (configForm) {
        setupAutoSave(configForm);
    }
    
    // Handle sync button states
    setupSyncButtons();
}

/**
 * Validate the add data form
 */
function validateAddDataForm(event) {
    const flowRate = document.getElementById('flow_rate').value;
    const pressure = document.getElementById('pressure').value;
    const temperature = document.getElementById('temperature').value;
    
    // Validate flow rate
    if (!flowRate || parseFloat(flowRate) <= 0) {
        showAlert('Flow rate must be greater than 0', 'error');
        event.preventDefault();
        return false;
    }
    
    // Validate numeric fields
    if (pressure && isNaN(parseFloat(pressure))) {
        showAlert('Pressure must be a valid number', 'error');
        event.preventDefault();
        return false;
    }
    
    if (temperature && isNaN(parseFloat(temperature))) {
        showAlert('Temperature must be a valid number', 'error');
        event.preventDefault();
        return false;
    }
    
    // Show loading state
    const submitBtn = event.target.querySelector('button[type="submit"]');
    if (submitBtn) {
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Adding...';
        submitBtn.disabled = true;
    }
    
    return true;
}

/**
 * Load and display chart data
 */
function loadChartData(hours = 24) {
    fetch(`/api/chart_data?hours=${hours}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('Error loading chart data:', data.error);
                showAlert('Failed to load chart data', 'error');
                return;
            }
            
            updateFlowChart(data);
            lastUpdateTime = new Date();
        })
        .catch(error => {
            console.error('Network error loading chart data:', error);
            showAlert('Network error loading chart data', 'error');
        });
}

/**
 * Update the flow rate chart
 */
function updateFlowChart(data) {
    const ctx = document.getElementById('flowRateChart');
    if (!ctx) return;
    
    // Destroy existing chart
    if (flowChart) {
        flowChart.destroy();
    }
    
    // Create new chart
    flowChart = new Chart(ctx.getContext('2d'), {
        type: 'line',
        data: {
            labels: data.labels || [],
            datasets: [{
                label: 'Flow Rate (L/min)',
                data: data.flow_rates || [],
                borderColor: '#0dcaf0',
                backgroundColor: 'rgba(13, 202, 240, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true,
                pointRadius: 3,
                pointHoverRadius: 6,
                pointBackgroundColor: '#0dcaf0',
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: {
                duration: 1000,
                easing: 'easeInOutQuart'
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        padding: 20,
                        font: {
                            size: 12,
                            weight: '500'
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    borderColor: '#0dcaf0',
                    borderWidth: 1,
                    cornerRadius: 6,
                    displayColors: false,
                    callbacks: {
                        title: function(context) {
                            return `Time: ${context[0].label}`;
                        },
                        label: function(context) {
                            return `Flow Rate: ${context.parsed.y} L/min`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Flow Rate (L/min)',
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        font: {
                            size: 11
                        }
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Time',
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        font: {
                            size: 11
                        },
                        maxTicksLimit: 10
                    }
                }
            }
        }
    });
}

/**
 * Setup auto-refresh functionality
 */
function startAutoRefresh() {
    // Refresh chart data every 5 minutes
    refreshInterval = setInterval(() => {
        loadChartData();
        updateTimestamps();
    }, 5 * 60 * 1000);
    
    // Update timestamps every minute
    setInterval(updateTimestamps, 60 * 1000);
}

/**
 * Update timestamp displays
 */
function updateTimestamps() {
    const now = new Date();
    const timeString = now.toLocaleString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    
    // Update last updated time
    const lastUpdatedEl = document.getElementById('last-updated');
    if (lastUpdatedEl) {
        lastUpdatedEl.textContent = timeString;
    }
    
    // Update relative timestamps
    document.querySelectorAll('[data-timestamp]').forEach(el => {
        const timestamp = new Date(el.getAttribute('data-timestamp'));
        const diff = now - timestamp;
        el.textContent = formatRelativeTime(diff);
    });
}

/**
 * Format relative time
 */
function formatRelativeTime(diff) {
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
    if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    return 'Just now';
}

/**
 * Setup sync buttons with loading states
 */
function setupSyncButtons() {
    document.querySelectorAll('a[href*="sync"]').forEach(button => {
        button.addEventListener('click', function(e) {
            // Show loading state
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Syncing...';
            this.classList.add('disabled');
            
            // Reset button after a delay (in case of redirect)
            setTimeout(() => {
                this.innerHTML = originalText;
                this.classList.remove('disabled');
            }, 5000);
        });
    });
}

/**
 * Setup auto-save for configuration form
 */
function setupAutoSave(form) {
    const inputs = form.querySelectorAll('input, select, textarea');
    let autoSaveTimeout;
    
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            clearTimeout(autoSaveTimeout);
            autoSaveTimeout = setTimeout(() => {
                saveConfigurationAuto();
            }, 2000); // Auto-save after 2 seconds of inactivity
        });
    });
}

/**
 * Auto-save configuration (could be enhanced to use AJAX)
 */
function saveConfigurationAuto() {
    // This is a placeholder for auto-save functionality
    // In a real implementation, you might want to save via AJAX
    console.log('Auto-save triggered (placeholder)');
}

/**
 * Show alert message
 */
function showAlert(message, type = 'info') {
    const alertContainer = document.querySelector('.container');
    if (!alertContainer) return;
    
    const alertEl = document.createElement('div');
    alertEl.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show`;
    alertEl.innerHTML = `
        <i class="fas fa-${getAlertIcon(type)} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insert at the top of the container
    alertContainer.insertBefore(alertEl, alertContainer.firstChild);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        if (alertEl.parentNode) {
            alertEl.remove();
        }
    }, 5000);
}

/**
 * Get appropriate icon for alert type
 */
function getAlertIcon(type) {
    switch (type) {
        case 'error': return 'exclamation-triangle';
        case 'success': return 'check-circle';
        case 'warning': return 'exclamation-circle';
        default: return 'info-circle';
    }
}

/**
 * Show welcome message for first-time users
 */
function showWelcomeMessage() {
    const welcomeHtml = `
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <i class="fas fa-star me-2"></i>
            <strong>Welcome to GAG Dashboard!</strong> 
            This is your autonomous flow monitoring system. Add data manually or sync with Google Sheets to get started.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    const container = document.querySelector('.container');
    if (container) {
        container.insertAdjacentHTML('afterbegin', welcomeHtml);
    }
}

/**
 * Handle page visibility changes (pause/resume updates)
 */
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        // Page is hidden, pause updates
        if (refreshInterval) {
            clearInterval(refreshInterval);
        }
    } else {
        // Page is visible, resume updates
        startAutoRefresh();
        loadChartData(); // Immediate update
    }
});

/**
 * Handle window focus/blur for better performance
 */
window.addEventListener('focus', function() {
    // Refresh data when window gains focus
    loadChartData();
});

/**
 * Error handling for uncaught errors
 */
window.addEventListener('error', function(e) {
    console.error('Uncaught error:', e.error);
    showAlert('An unexpected error occurred. Please refresh the page.', 'error');
});

/**
 * Handle network connectivity
 */
window.addEventListener('online', function() {
    showAlert('Connection restored', 'success');
    loadChartData();
});

window.addEventListener('offline', function() {
    showAlert('Connection lost. Data will be saved locally and synced when connection is restored.', 'warning');
});

// Export functions for potential use in other scripts
window.GAGDashboard = {
    loadChartData,
    updateFlowChart,
    showAlert,
    formatRelativeTime
};
