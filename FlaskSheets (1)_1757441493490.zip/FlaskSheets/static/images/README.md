# Pasta de Imagens

Coloque aqui:
- logotipo_gag.png (logotipo principal)
- favicon.ico (ícone do site)
- portfolio/ (trabalhos realizados)

Formatos suportados: PNG, JPG, JPEG, SVG