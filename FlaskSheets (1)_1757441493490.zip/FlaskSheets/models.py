from datetime import datetime
from app import db

class FlowData(db.Model):
    """Model for storing autonomous flow data from GAG system"""
    __tablename__ = 'flow_data'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    flow_rate = db.Column(db.Float, nullable=False)  # Flow rate in L/min or similar unit
    pressure = db.Column(db.Float, nullable=True)    # Pressure reading
    temperature = db.Column(db.Float, nullable=True) # Temperature reading
    status = db.Column(db.String(50), nullable=False, default='active')  # System status
    location = db.Column(db.String(100), nullable=True)  # Location identifier
    device_id = db.Column(db.String(50), nullable=True)  # Device identifier
    notes = db.Column(db.Text, nullable=True)        # Additional notes
    synced_to_sheets = db.Column(db.Boolean, default=False)  # Track sync status
    
    def __repr__(self):
        return f'<FlowData {self.id}: {self.flow_rate} at {self.timestamp}>'
    
    def to_dict(self):
        """Convert model to dictionary for easy serialization"""
        return {
            'id': self.id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'flow_rate': self.flow_rate,
            'pressure': self.pressure,
            'temperature': self.temperature,
            'status': self.status,
            'location': self.location,
            'device_id': self.device_id,
            'notes': self.notes,
            'synced_to_sheets': self.synced_to_sheets
        }

class SystemConfig(db.Model):
    """Model for storing system configuration"""
    __tablename__ = 'system_config'
    
    id = db.Column(db.Integer, primary_key=True)
    config_key = db.Column(db.String(100), unique=True, nullable=False)
    config_value = db.Column(db.Text, nullable=True)
    description = db.Column(db.String(255), nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<SystemConfig {self.config_key}: {self.config_value}>'

class SyncLog(db.Model):
    """Model for tracking Google Sheets synchronization logs"""
    __tablename__ = 'sync_log'
    
    id = db.Column(db.Integer, primary_key=True)
    sync_timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    records_synced = db.Column(db.Integer, default=0)
    sync_status = db.Column(db.String(20), nullable=False)  # 'success', 'error', 'partial'
    error_message = db.Column(db.Text, nullable=True)
    sync_direction = db.Column(db.String(20), nullable=False)  # 'to_sheets', 'from_sheets'
    
    def __repr__(self):
        return f'<SyncLog {self.id}: {self.sync_status} at {self.sync_timestamp}>'
