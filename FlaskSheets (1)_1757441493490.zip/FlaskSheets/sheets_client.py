import gspread
from google.oauth2.service_account import Credentials
import os
import logging

logger = logging.getLogger(__name__)

class SheetsClient:
    def __init__(self, credentials_path: str, sheet_id: str):
        try:
            scopes = [
                'https://www.googleapis.com/auth/spreadsheets',
                'https://www.googleapis.com/auth/drive'
            ]
            creds = Credentials.from_service_account_file(credentials_path, scopes=scopes)
            client = gspread.authorize(creds)
            self.sheet = client.open_by_key(sheet_id) if sheet_id else None
            logger.info("Google Sheets client initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Google Sheets client: {e}")
            self.sheet = None

    def get_records(self, worksheet_name=None):
        """Obter todos os registros da planilha"""
        if not self.sheet:
            return []
        try:
            ws = self.sheet.worksheet(worksheet_name) if worksheet_name else self.sheet.sheet1
            return ws.get_all_records()  # lista de dicts
        except Exception as e:
            logger.error(f"Failed to get records: {e}")
            return []

    def append_row(self, values, worksheet_name=None):
        """Adicionar uma linha à planilha"""
        if not self.sheet:
            return False
        try:
            ws = self.sheet.worksheet(worksheet_name) if worksheet_name else self.sheet.sheet1
            ws.append_row(values)
            return True
        except Exception as e:
            logger.error(f"Failed to append row: {e}")
            return False

    def update_range(self, range_name, values, worksheet_name=None):
        """Atualizar um intervalo específico"""
        if not self.sheet:
            return False
        try:
            ws = self.sheet.worksheet(worksheet_name) if worksheet_name else self.sheet.sheet1
            ws.update(range_name, values)
            return True
        except Exception as e:
            logger.error(f"Failed to update range: {e}")
            return False

    def create_worksheet(self, title, rows=1000, cols=10):
        """Criar uma nova planilha"""
        if not self.sheet:
            return None
        try:
            return self.sheet.add_worksheet(title, rows, cols)
        except Exception as e:
            logger.error(f"Failed to create worksheet: {e}")
            return None

# Instância global do cliente
sheets_client = None

def get_sheets_client():
    """Obter instância do cliente Google Sheets"""
    global sheets_client
    from app import app
    
    if sheets_client is None:
        credentials_path = app.config.get('GOOGLE_CREDENTIALS_PATH')
        sheet_id = app.config.get('GOOGLE_SHEETS_ID')
        
        if credentials_path and os.path.exists(credentials_path) and sheet_id:
            sheets_client = SheetsClient(credentials_path, sheet_id)
        else:
            logger.warning("Google Sheets not configured properly")
            
    return sheets_client