# GAG Dashboard

## Overview

GAG Dashboard is a Flask-based web application for monitoring autonomous flow systems. It provides real-time data visualization, Google Sheets integration for data synchronization, and a comprehensive dashboard for tracking flow rates, pressure, temperature, and system status across multiple devices.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

**Backend Framework**: Flask with SQLAlchemy ORM for database operations and RESTful API endpoints.

**Database Layer**: SQLite for local development with configurable database URI for production deployments. Uses SQLAlchemy models for data persistence with three main entities:
- FlowData: Stores autonomous flow measurements including flow rate, pressure, temperature, and device metadata
- SystemConfig: Manages application configuration settings
- SyncLog: Tracks synchronization operations with external services

**Frontend Architecture**: Server-side rendered HTML templates using Jinja2 with Bootstrap dark theme for responsive UI. Includes Chart.js for data visualization and Font Awesome icons for enhanced user experience.

**Authentication & Security**: Uses Flask session management with configurable secret keys and proxy-aware middleware for deployment behind reverse proxies.

**Data Synchronization**: Dedicated Google Sheets service class handles bidirectional data sync using Google Sheets API with proper OAuth2 authentication and error handling.

**API Design**: RESTful routes handle dashboard views, data management, and configuration updates with JSON responses for AJAX operations.

**Static Assets**: Organized CSS and JavaScript files for custom styling and interactive dashboard functionality including real-time updates and form validation.

## External Dependencies

**Google Services**: 
- Google Sheets API for data synchronization
- Google Drive API for spreadsheet access
- gspread library for Python-based sheet operations

**Frontend Libraries**:
- Bootstrap (via Replit CDN) for responsive UI components
- Chart.js for data visualization and analytics
- Font Awesome for iconography

**Python Packages**:
- Flask for web framework
- SQLAlchemy for database ORM
- gspread for Google Sheets integration
- google-auth for OAuth2 authentication

**Development Tools**:
- Werkzeug ProxyFix for deployment compatibility
- Python logging for application monitoring

**Environment Configuration**:
- DATABASE_URL for database connection
- GOOGLE_SHEET_URL for spreadsheet integration
- SESSION_SECRET for Flask session security