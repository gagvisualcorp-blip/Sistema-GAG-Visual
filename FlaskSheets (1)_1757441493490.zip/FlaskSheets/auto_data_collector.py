import random
import time
import threading
from datetime import datetime, timedelta
from app import app, db
from models import FlowData
import logging

class AutoDataCollector:
    """Sistema de coleta automática de dados de dispositivos GAG"""
    
    def __init__(self):
        self.active = True
        self.devices = [
            {"id": "GAG-CENTRAL", "location": "Escritório Central", "base_flow": 2.1},
            {"id": "GAG-NORTE", "location": "Filial Norte", "base_flow": 1.8},
            {"id": "GAG-SUL", "location": "Filial Sul", "base_flow": 1.9},
            {"id": "GAG-FABRICA", "location": "Fábrica Principal", "base_flow": 2.5},
            {"id": "GAG-DEPOSITO", "location": "Centro Logístico", "base_flow": 1.6},
            {"id": "GAG-LOJA1", "location": "Loja Talatona", "base_flow": 1.4},
            {"id": "GAG-LOJA2", "location": "Loja Maianga", "base_flow": 1.7},
            {"id": "GAG-BACKUP", "location": "Sistema Backup", "base_flow": 0.8},
        ]
        self.collection_interval = 60  # Coleta a cada 60 segundos
        
    def simulate_real_device_data(self, device):
        """Simula dados reais de um dispositivo IoT"""
        base_flow = device["base_flow"]
        
        # Variação natural do fluxo (±20%)
        flow_variation = random.uniform(-0.2, 0.2)
        flow_rate = base_flow * (1 + flow_variation)
        
        # Pressão correlacionada com fluxo
        pressure = 2.0 + (flow_rate * 0.5) + random.uniform(-0.1, 0.1)
        
        # Temperatura ambiente com variação diária
        hour = datetime.now().hour
        base_temp = 23 + (2 * abs(hour - 12) / 12)  # Variação diária
        temperature = base_temp + random.uniform(-1, 1)
        
        # Status baseado em condições
        if flow_rate < 0.5:
            status = "error"
        elif flow_rate < base_flow * 0.7:
            status = "warning"
        else:
            status = "active"
            
        return {
            "device_id": device["id"],
            "location": device["location"],
            "flow_rate": round(flow_rate, 2),
            "pressure": round(pressure, 2),
            "temperature": round(temperature, 1),
            "status": status
        }
    
    def collect_from_device(self, device):
        """Coleta dados de um dispositivo específico"""
        try:
            data = self.simulate_real_device_data(device)
            
            with app.app_context():
                flow_record = FlowData(
                    timestamp=datetime.utcnow(),
                    flow_rate=data["flow_rate"],
                    pressure=data["pressure"],
                    temperature=data["temperature"],
                    status=data["status"],
                    location=data["location"],
                    device_id=data["device_id"],
                    notes=f"Coleta automática - {datetime.now().strftime('%H:%M:%S')}"
                )
                
                db.session.add(flow_record)
                db.session.commit()
                
                logging.info(f"Dados coletados de {data['device_id']}: {data['flow_rate']} L/min")
                
        except Exception as e:
            logging.error(f"Erro ao coletar dados de {device['id']}: {str(e)}")
    
    def collect_all_devices(self):
        """Coleta dados de todos os dispositivos"""
        if not self.active:
            return
            
        logging.info("Iniciando coleta automática de dados...")
        
        for device in self.devices:
            # Simula delay entre dispositivos (comunicação real)
            time.sleep(random.uniform(0.5, 2.0))
            self.collect_from_device(device)
        
        logging.info(f"Coleta completa. {len(self.devices)} dispositivos processados.")
    
    def start_auto_collection(self):
        """Inicia coleta automática em background"""
        def collection_loop():
            while self.active:
                try:
                    self.collect_all_devices()
                    time.sleep(self.collection_interval)
                except Exception as e:
                    logging.error(f"Erro na coleta automática: {str(e)}")
                    time.sleep(30)  # Aguarda 30s antes de tentar novamente
        
        # Inicia thread de coleta
        collection_thread = threading.Thread(target=collection_loop, daemon=True)
        collection_thread.start()
        logging.info("Sistema de coleta automática iniciado!")
    
    def stop_collection(self):
        """Para a coleta automática"""
        self.active = False
        logging.info("Sistema de coleta automática parado.")
    
    def get_device_status(self):
        """Retorna status atual dos dispositivos"""
        status_list = []
        for device in self.devices:
            try:
                with app.app_context():
                    last_record = FlowData.query.filter_by(device_id=device["id"]).order_by(FlowData.timestamp.desc()).first()
                    
                    if last_record:
                        # Verifica se o último registro é recente (últimos 5 minutos)
                        is_recent = (datetime.utcnow() - last_record.timestamp).total_seconds() < 300
                        
                        status_list.append({
                            "device_id": device["id"],
                            "location": device["location"],
                            "last_flow": last_record.flow_rate,
                            "status": last_record.status,
                            "last_update": last_record.timestamp,
                            "is_online": is_recent
                        })
                    else:
                        status_list.append({
                            "device_id": device["id"],
                            "location": device["location"],
                            "last_flow": 0,
                            "status": "offline",
                            "last_update": None,
                            "is_online": False
                        })
                        
            except Exception as e:
                logging.error(f"Erro ao obter status de {device['id']}: {str(e)}")
        
        return status_list

# Instância global do coletor
data_collector = AutoDataCollector()

def init_auto_collector():
    """Inicializa o sistema de coleta automática"""
    logging.info("Inicializando sistema de coleta automática GAG...")
    data_collector.start_auto_collection()

def get_collector_status():
    """Retorna status do sistema de coleta"""
    return {
        "active": data_collector.active,
        "devices_count": len(data_collector.devices),
        "interval": data_collector.collection_interval,
        "devices": data_collector.get_device_status()
    }