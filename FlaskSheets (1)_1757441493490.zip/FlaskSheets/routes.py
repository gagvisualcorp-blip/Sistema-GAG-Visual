from flask import render_template, request, redirect, url_for, flash, jsonify
from datetime import datetime, timedelta
from sqlalchemy import desc, func
from app import app, db
from models import FlowData, SystemConfig, SyncLog
from google_sheets_service import sheets_service
import logging

logger = logging.getLogger(__name__)

@app.route('/')
def dashboard():
    """Main dashboard view"""
    # Get recent flow data (last 24 hours)
    last_24h = datetime.utcnow() - timedelta(hours=24)
    recent_data = FlowData.query.filter(
        FlowData.timestamp >= last_24h
    ).order_by(desc(FlowData.timestamp)).limit(100).all()
    
    # Get summary statistics
    total_records = FlowData.query.count()
    active_devices = db.session.query(FlowData.device_id).distinct().count()
    
    # Calculate average flow rate for last 24h
    avg_flow = db.session.query(func.avg(FlowData.flow_rate)).filter(
        FlowData.timestamp >= last_24h
    ).scalar() or 0
    
    # Get latest sync status
    latest_sync = SyncLog.query.order_by(desc(SyncLog.sync_timestamp)).first()
    
    # Get system status
    system_status = 'operational'
    if recent_data:
        latest_record = recent_data[0]
        if latest_record.status != 'active':
            system_status = 'warning'
        # Check if latest data is more than 1 hour old
        if (datetime.utcnow() - latest_record.timestamp).total_seconds() > 3600:
            system_status = 'offline'
    else:
        system_status = 'no_data'
    
    return render_template('dashboard.html',
                         recent_data=recent_data,
                         total_records=total_records,
                         active_devices=active_devices,
                         avg_flow=round(avg_flow, 2),
                         latest_sync=latest_sync,
                         system_status=system_status)

@app.route('/add_data', methods=['POST'])
def add_data():
    """Add new flow data record"""
    try:
        flow_rate = float(request.form.get('flow_rate', 0))
        pressure = request.form.get('pressure')
        temperature = request.form.get('temperature')
        status = request.form.get('status', 'active')
        location = request.form.get('location')
        device_id = request.form.get('device_id')
        notes = request.form.get('notes')
        
        # Validate required fields
        if flow_rate <= 0:
            flash('Flow rate must be greater than 0', 'error')
            return redirect(url_for('dashboard'))
        
        new_record = FlowData(
            flow_rate=flow_rate,
            pressure=float(pressure) if pressure else None,
            temperature=float(temperature) if temperature else None,
            status=status,
            location=location,
            device_id=device_id,
            notes=notes
        )
        
        db.session.add(new_record)
        db.session.commit()
        
        flash('Data record added successfully', 'success')
        logger.info(f"New data record added: Flow rate {flow_rate}")
        
    except ValueError as e:
        flash('Invalid numeric values provided', 'error')
        logger.error(f"ValueError adding data: {e}")
    except Exception as e:
        flash('Error adding data record', 'error')
        logger.error(f"Error adding data: {e}")
        db.session.rollback()
    
    return redirect(url_for('dashboard'))

@app.route('/sync_to_sheets')
def sync_to_sheets():
    """Sync unsynced records to Google Sheets"""
    try:
        # Get unsynced records
        unsynced_records = FlowData.query.filter_by(synced_to_sheets=False).all()
        
        if not unsynced_records:
            flash('No unsynced records found', 'info')
            return redirect(url_for('dashboard'))
        
        # Sync to sheets
        result = sheets_service.sync_to_sheets(unsynced_records)
        
        if result['success']:
            flash(f"Successfully synced {result['records_synced']} records to Google Sheets", 'success')
        else:
            flash(f"Failed to sync to Google Sheets: {result.get('error', 'Unknown error')}", 'error')
    
    except Exception as e:
        flash(f'Error during sync: {str(e)}', 'error')
        logger.error(f"Error syncing to sheets: {e}")
    
    return redirect(url_for('dashboard'))

@app.route('/sync_from_sheets')
def sync_from_sheets():
    """Sync data from Google Sheets to local database"""
    try:
        result = sheets_service.sync_from_sheets()
        
        if result['success']:
            flash(f"Successfully synced {result['records_synced']} new records from Google Sheets", 'success')
        else:
            flash(f"Failed to sync from Google Sheets: {result.get('error', 'Unknown error')}", 'error')
    
    except Exception as e:
        flash(f'Error during sync: {str(e)}', 'error')
        logger.error(f"Error syncing from sheets: {e}")
    
    return redirect(url_for('dashboard'))

@app.route('/test_sheets_connection')
def test_sheets_connection():
    """Test Google Sheets connection"""
    try:
        result = sheets_service.test_connection()
        
        if result['success']:
            flash(f"Successfully connected to Google Sheets: {result.get('sheet_title', 'Unknown')}", 'success')
        else:
            flash(f"Failed to connect to Google Sheets: {result.get('error', 'Unknown error')}", 'error')
    
    except Exception as e:
        flash(f'Error testing connection: {str(e)}', 'error')
        logger.error(f"Error testing sheets connection: {e}")
    
    return redirect(url_for('settings'))

@app.route('/settings')
def settings():
    """Settings page"""
    # Get system configuration
    configs = SystemConfig.query.all()
    config_dict = {config.config_key: config.config_value for config in configs}
    
    # Get recent sync logs
    recent_syncs = SyncLog.query.order_by(desc(SyncLog.sync_timestamp)).limit(10).all()
    
    return render_template('settings.html',
                         config=config_dict,
                         recent_syncs=recent_syncs)

@app.route('/update_config', methods=['POST'])
def update_config():
    """Update system configuration"""
    try:
        for key, value in request.form.items():
            if key.startswith('config_'):
                config_key = key.replace('config_', '')
                
                # Update or create config
                config = SystemConfig.query.filter_by(config_key=config_key).first()
                if config:
                    config.config_value = value
                    config.updated_at = datetime.utcnow()
                else:
                    config = SystemConfig(
                        config_key=config_key,
                        config_value=value,
                        description=f"Configuration for {config_key}"
                    )
                    db.session.add(config)
        
        db.session.commit()
        flash('Configuration updated successfully', 'success')
        
    except Exception as e:
        flash('Error updating configuration', 'error')
        logger.error(f"Error updating config: {e}")
        db.session.rollback()
    
    return redirect(url_for('settings'))

@app.route('/api/chart_data')
def api_chart_data():
    """API endpoint for chart data"""
    try:
        hours = int(request.args.get('hours', 24))
        since = datetime.utcnow() - timedelta(hours=hours)
        
        data = FlowData.query.filter(
            FlowData.timestamp >= since
        ).order_by(FlowData.timestamp).all()
        
        chart_data = {
            'labels': [record.timestamp.strftime('%H:%M') for record in data],
            'flow_rates': [record.flow_rate for record in data],
            'pressures': [record.pressure for record in data if record.pressure],
            'temperatures': [record.temperature for record in data if record.temperature]
        }
        
        return jsonify(chart_data)
    
    except Exception as e:
        logger.error(f"Error getting chart data: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/delete_record/<int:record_id>')
def delete_record(record_id):
    """Delete a flow data record"""
    try:
        record = FlowData.query.get_or_404(record_id)
        db.session.delete(record)
        db.session.commit()
        flash('Record deleted successfully', 'success')
        
    except Exception as e:
        flash('Error deleting record', 'error')
        logger.error(f"Error deleting record {record_id}: {e}")
        db.session.rollback()
    
    return redirect(url_for('dashboard'))

@app.errorhandler(404)
def not_found(error):
    """404 error handler"""
    return render_template('dashboard.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """500 error handler"""
    db.session.rollback()
    logger.error(f"Internal error: {error}")
    return render_template('dashboard.html'), 500
